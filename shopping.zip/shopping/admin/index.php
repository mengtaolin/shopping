<?php
header("Location: http://b2b2c.wrtx.cn/admin");
exit();
?>
