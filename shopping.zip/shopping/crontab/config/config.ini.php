<?php
defined('InWrzcNet') or exit('Access Invalid!');
//$config = array();
$config['debug'] = false;
return $config;