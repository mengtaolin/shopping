<?php defined('InWrzcNet') or exit('Access Invalid!');?>
<?php
require_once($tpl_file);
?>