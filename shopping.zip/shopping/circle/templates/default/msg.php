<?php defined('InWrzcNet') or exit('Access Invalid!');?>
<?php echo $output['msg']; ?>