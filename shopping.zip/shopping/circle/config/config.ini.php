<?php
defined('InWrzcNet') or exit('Access Invalid!');
//网站地址，最后不要斜杠
//$config['circle_site_url'] = 'http://127.0.0.1/trunk/modules/circle';
////当前风格
//$config['tpl_name'] = 'default';