<?php
defined('InWrzcNet') or exit('Access Invalid!');

$lang['circle_default_series']	= '默认系列';
$lang['circle_custom']			= '自定义';
$lang['circle_level']			= '级别';
$lang['circle_exp']				= '经验';
$lang['circle_rank']			= '头衔';
$lang['circle_submit_setting']		= '提交设置';