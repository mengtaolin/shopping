<?php
defined('InWrzcNet') or exit('Access Invalid!');

$lang['cut_working_area']	= '工作区域';
$lang['cut_preview']		= '裁切预览';
$lang['cut_help']			= '操作帮助';
$lang['cut_help_tips']		= '请在工作区域放大缩小及移动选取框，选择要裁剪的范围，裁切宽高比例为1:1；裁切后的效果为右侧预览图所显示；保存提交后生效。';
$lang['cut_submit']			= '提交';