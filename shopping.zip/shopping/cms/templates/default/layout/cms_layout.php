<?php defined('InWrzcNet') or exit('Access Invalid!');?>
<?php require CMS_BASE_TPL_PATH.'/layout/top.php';?>
<?php require CMS_BASE_TPL_PATH.'/layout/nav.php';?>
<div class="pt20">
    <?php require_once($tpl_file);?>
</div>
<?php require CMS_BASE_TPL_PATH.'/layout/footer.php';?>
