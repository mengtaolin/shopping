<?php defined('InWrzcNet') or exit('Access Invalid!');?>
<div id="body">
  <div class="cms-content">
    <?php require($output['special_file']); ?>
  </div>
</div>
