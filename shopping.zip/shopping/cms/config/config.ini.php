<?php
defined('InWrzcNet') or exit('Access Invalid!');
