<?php
defined('InWrzcNet') or exit('Access Invalid!');
define('NODE_SITE_URL','http://118.244.237.53:8090');
define('CHAT_SITE_URL','http://v3.baidu.com/chat');

define('CHAT_TEMPLATES_URL',CHAT_SITE_URL.'/templates/default');
define('CHAT_RESOURCE_URL',CHAT_SITE_URL.'/resource');