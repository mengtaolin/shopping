<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  'index' => 
  array (
    'id' => '1',
    'title' => '{sitename}购物网站欢迎您',
    'keywords' => '{sitename}网店系统,商城系统',
    'description' => '{sitename}',
    'type' => 'index',
  ),
  'group' => 
  array (
    'id' => '2',
    'title' => '{sitename} - 团购',
    'keywords' => '{name},{sitename}',
    'description' => '{name},{sitename}',
    'type' => 'group',
  ),
  'group_content' => 
  array (
    'id' => '3',
    'title' => '{sitename} - {name}',
    'keywords' => '{name},{sitename}',
    'description' => '{name},{sitename}',
    'type' => 'group_content',
  ),
  'brand' => 
  array (
    'id' => '4',
    'title' => '{sitename} - 品牌',
    'keywords' => '{name},{sitename}',
    'description' => '{name},{sitename}',
    'type' => 'brand',
  ),
  'brand_list' => 
  array (
    'id' => '5',
    'title' => '{sitename} - {name}',
    'keywords' => '{name},{sitename}',
    'description' => '{name},{sitename}',
    'type' => 'brand_list',
  ),
  'coupon_content' => 
  array (
    'id' => '7',
    'title' => '{sitename} - {name}',
    'keywords' => '多用户商城,{sitename},{name}',
    'description' => '多用户商城,{sitename},{name}',
    'type' => 'coupon_content',
  ),
  'point' => 
  array (
    'id' => '8',
    'title' => '{sitename} - 积分商城',
    'keywords' => '{name},{sitename}',
    'description' => '{name},{sitename}',
    'type' => 'point',
  ),
  'point_content' => 
  array (
    'id' => '9',
    'title' => '{sitename} - {name}',
    'keywords' => '{key}',
    'description' => '{description}',
    'type' => 'point_content',
  ),
  'article' => 
  array (
    'id' => '10',
    'title' => '{sitename} - {article_class}',
    'keywords' => '{sitename} - {article_class}',
    'description' => '{sitename}',
    'type' => 'article',
  ),
  'article_content' => 
  array (
    'id' => '11',
    'title' => '{sitename} - {name}',
    'keywords' => '{sitename},{key}',
    'description' => '{sitename},{description}',
    'type' => 'article_content',
  ),
  'shop' => 
  array (
    'id' => '12',
    'title' => '{sitename} - {shopname}',
    'keywords' => '{sitename},{key}',
    'description' => '{sitename},{description}',
    'type' => 'shop',
  ),
  'product' => 
  array (
    'id' => '13',
    'title' => '{name} - {sitename}',
    'keywords' => '{sitename},{key}',
    'description' => '{sitename},{description}',
    'type' => 'product',
  ),
  'sns' => 
  array (
    'id' => '14',
    'title' => '看{name}怎么淘到好的宝贝-{sitename}',
    'keywords' => '{sitename},{name}',
    'description' => '{sitename},{name}',
    'type' => 'sns',
  ),
);