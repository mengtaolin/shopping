<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  2 => 
  array (
    'sc_id' => '2',
    'sc_name' => '服装鞋包',
    'sc_bail' => '0',
    'sc_sort' => '1',
  ),
  3 => 
  array (
    'sc_id' => '3',
    'sc_name' => '3C数码',
    'sc_bail' => '0',
    'sc_sort' => '2',
  ),
  4 => 
  array (
    'sc_id' => '4',
    'sc_name' => '美容护理',
    'sc_bail' => '0',
    'sc_sort' => '3',
  ),
  5 => 
  array (
    'sc_id' => '5',
    'sc_name' => '家居用品',
    'sc_bail' => '0',
    'sc_sort' => '4',
  ),
  6 => 
  array (
    'sc_id' => '6',
    'sc_name' => '食品/保健',
    'sc_bail' => '0',
    'sc_sort' => '5',
  ),
  7 => 
  array (
    'sc_id' => '7',
    'sc_name' => '母婴用品',
    'sc_bail' => '0',
    'sc_sort' => '6',
  ),
  8 => 
  array (
    'sc_id' => '8',
    'sc_name' => '文体/汽车',
    'sc_bail' => '0',
    'sc_sort' => '7',
  ),
  1 => 
  array (
    'sc_id' => '1',
    'sc_name' => '珠宝/首饰',
    'sc_bail' => '0',
    'sc_sort' => '8',
  ),
  9 => 
  array (
    'sc_id' => '9',
    'sc_name' => '收藏/爱好',
    'sc_bail' => '0',
    'sc_sort' => '9',
  ),
  10 => 
  array (
    'sc_id' => '10',
    'sc_name' => '生活/服务',
    'sc_bail' => '0',
    'sc_sort' => '10',
  ),
);