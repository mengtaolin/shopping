<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  0 => 
  array (
    'nav_id' => '19',
    'nav_type' => '0',
    'nav_title' => '闲置',
    'nav_url' => '/shop/index.php?act=flea',
    'nav_location' => '1',
    'nav_new_open' => '0',
    'nav_sort' => '238',
    'item_id' => '0',
  ),
  1 => 
  array (
    'nav_id' => '7',
    'nav_type' => '0',
    'nav_title' => '联系我们',
    'nav_url' => '/shop/index.php?act=article&amp;article_id=23',
    'nav_location' => '2',
    'nav_new_open' => '0',
    'nav_sort' => '240',
    'item_id' => '0',
  ),
  2 => 
  array (
    'nav_id' => '9',
    'nav_type' => '0',
    'nav_title' => '招聘英才',
    'nav_url' => '/shop/index.php?act=article&amp;article_id=24',
    'nav_location' => '2',
    'nav_new_open' => '0',
    'nav_sort' => '242',
    'item_id' => '0',
  ),
  3 => 
  array (
    'nav_id' => '8',
    'nav_type' => '0',
    'nav_title' => '合作及洽谈',
    'nav_url' => '/shop/index.php?act=article&amp;article_id=25',
    'nav_location' => '2',
    'nav_new_open' => '0',
    'nav_sort' => '243',
    'item_id' => '0',
  ),
  4 => 
  array (
    'nav_id' => '6',
    'nav_type' => '0',
    'nav_title' => '关于我们',
    'nav_url' => '/shop/index.php?act=article&amp;article_id=22',
    'nav_location' => '2',
    'nav_new_open' => '0',
    'nav_sort' => '255',
    'item_id' => '0',
  ),
  5 => 
  array (
    'nav_id' => '11',
    'nav_type' => '0',
    'nav_title' => '店铺',
    'nav_url' => '/shop/index.php?act=store_list&amp;op=index',
    'nav_location' => '1',
    'nav_new_open' => '0',
    'nav_sort' => '255',
    'item_id' => '0',
  ),
  6 => 
  array (
    'nav_id' => '13',
    'nav_type' => '0',
    'nav_title' => '资讯',
    'nav_url' => '/cms',
    'nav_location' => '1',
    'nav_new_open' => '0',
    'nav_sort' => '255',
    'item_id' => '0',
  ),
  7 => 
  array (
    'nav_id' => '14',
    'nav_type' => '0',
    'nav_title' => '圈子',
    'nav_url' => '/circle',
    'nav_location' => '1',
    'nav_new_open' => '0',
    'nav_sort' => '255',
    'item_id' => '0',
  ),
  8 => 
  array (
    'nav_id' => '15',
    'nav_type' => '0',
    'nav_title' => '微商城',
    'nav_url' => '/microshop',
    'nav_location' => '1',
    'nav_new_open' => '0',
    'nav_sort' => '255',
    'item_id' => '0',
  ),
  9 => 
  array (
    'nav_id' => '16',
    'nav_type' => '0',
    'nav_title' => '友情链接',
    'nav_url' => '/shop/index.php?act=link',
    'nav_location' => '2',
    'nav_new_open' => '0',
    'nav_sort' => '255',
    'item_id' => '0',
  ),
  10 => 
  array (
    'nav_id' => '17',
    'nav_type' => '0',
    'nav_title' => 'F码',
    'nav_url' => '/shop/index.php?act=goods&amp;op=index&amp;goods_id=100068',
    'nav_location' => '1',
    'nav_new_open' => '1',
    'nav_sort' => '255',
    'item_id' => '0',
  ),
  11 => 
  array (
    'nav_id' => '18',
    'nav_type' => '0',
    'nav_title' => '预售',
    'nav_url' => '/shop/index.php?act=goods&amp;op=index&amp;goods_id=100069',
    'nav_location' => '1',
    'nav_new_open' => '1',
    'nav_sort' => '255',
    'item_id' => '0',
  ),
);