<?php
$show_article=array (
  'notice' => 
  array (
    'ac_id' => '1',
    'ac_code' => 'notice',
    'ac_name' => '商城公告',
    'ac_parent_id' => '0',
    'ac_sort' => '255',
    'list' => 
    array (
      0 => 
      array (
        'article_id' => '35',
        'ac_id' => '1',
        'article_url' => 'http://www.wrzc.net/',
        'article_title' => '火爆销售中',
        'article_time' => '1389864697',
        'ac_name' => '商城公告',
        'ac_parent_id' => '0',
      ),
      1 => 
      array (
        'article_id' => '36',
        'ac_id' => '1',
        'article_url' => '',
        'article_title' => '管理功能说明',
        'article_time' => '1389864697',
        'ac_name' => '商城公告',
        'ac_parent_id' => '0',
      ),
      2 => 
      array (
        'article_id' => '38',
        'ac_id' => '1',
        'article_url' => '',
        'article_title' => '提示信息',
        'article_time' => '1389864697',
        'ac_name' => '商城公告',
        'ac_parent_id' => '0',
      ),
      3 => 
      array (
        'article_id' => '37',
        'ac_id' => '1',
        'article_url' => '',
        'article_title' => '如何扩充水印字体库',
        'article_time' => '1389864697',
        'ac_name' => '商城公告',
        'ac_parent_id' => '0',
      ),
      4 => 
      array (
        'article_id' => '41',
        'ac_id' => '1',
        'article_url' => '',
        'article_title' => '功能使用说明',
        'article_time' => '1389864697',
        'ac_name' => '商城公告',
        'ac_parent_id' => '0',
      ),
    ),
  ),
);
$article_list=array (
  0 => 
  array (
    'ac_id' => '2',
    'ac_code' => 'member',
    'ac_name' => '帮助中心',
    'ac_parent_id' => '0',
    'ac_sort' => '255',
    'list' => 
    array (
      0 => 
      array (
        'article_id' => '10',
        'ac_id' => '2',
        'article_url' => '',
        'article_title' => '查看已购买商品',
        'article_time' => '1389864697',
        'ac_name' => '帮助中心',
        'ac_parent_id' => '0',
      ),
      1 => 
      array (
        'article_id' => '7',
        'ac_id' => '2',
        'article_url' => '',
        'article_title' => '如何搜索',
        'article_time' => '1389864697',
        'ac_name' => '帮助中心',
        'ac_parent_id' => '0',
      ),
      2 => 
      array (
        'article_id' => '40',
        'ac_id' => '2',
        'article_url' => '',
        'article_title' => '积分兑换说明',
        'article_time' => '1389864697',
        'ac_name' => '帮助中心',
        'ac_parent_id' => '0',
      ),
      3 => 
      array (
        'article_id' => '9',
        'ac_id' => '2',
        'article_url' => '',
        'article_title' => '我要买',
        'article_time' => '1389864697',
        'ac_name' => '帮助中心',
        'ac_parent_id' => '0',
      ),
      4 => 
      array (
        'article_id' => '6',
        'ac_id' => '2',
        'article_url' => '',
        'article_title' => '如何注册成为会员',
        'article_time' => '1389864697',
        'ac_name' => '帮助中心',
        'ac_parent_id' => '0',
      ),
    ),
    'class' => 
    array (
      'ac_name' => '帮助中心',
    ),
  ),
  1 => 
  array (
    'ac_id' => '3',
    'ac_code' => 'store',
    'ac_name' => '店主之家',
    'ac_parent_id' => '0',
    'ac_sort' => '255',
    'list' => 
    array (
      0 => 
      array (
        'article_id' => '13',
        'ac_id' => '3',
        'article_url' => '',
        'article_title' => '如何发货',
        'article_time' => '1389864697',
        'ac_name' => '店主之家',
        'ac_parent_id' => '0',
      ),
      1 => 
      array (
        'article_id' => '15',
        'ac_id' => '3',
        'article_url' => '',
        'article_title' => '如何申请开店',
        'article_time' => '1389864697',
        'ac_name' => '店主之家',
        'ac_parent_id' => '0',
      ),
      2 => 
      array (
        'article_id' => '12',
        'ac_id' => '3',
        'article_url' => '',
        'article_title' => '查看售出商品',
        'article_time' => '1389864697',
        'ac_name' => '店主之家',
        'ac_parent_id' => '0',
      ),
      3 => 
      array (
        'article_id' => '14',
        'ac_id' => '3',
        'article_url' => '',
        'article_title' => '商城商品推荐',
        'article_time' => '1389864697',
        'ac_name' => '店主之家',
        'ac_parent_id' => '0',
      ),
      4 => 
      array (
        'article_id' => '11',
        'ac_id' => '3',
        'article_url' => '',
        'article_title' => '如何管理店铺',
        'article_time' => '1389864697',
        'ac_name' => '店主之家',
        'ac_parent_id' => '0',
      ),
    ),
    'class' => 
    array (
      'ac_name' => '店主之家',
    ),
  ),
  2 => 
  array (
    'ac_id' => '4',
    'ac_code' => 'payment',
    'ac_name' => '支付方式',
    'ac_parent_id' => '0',
    'ac_sort' => '255',
    'list' => 
    array (
      0 => 
      array (
        'article_id' => '16',
        'ac_id' => '4',
        'article_url' => '',
        'article_title' => '如何注册支付宝',
        'article_time' => '1389864697',
        'ac_name' => '支付方式',
        'ac_parent_id' => '0',
      ),
      1 => 
      array (
        'article_id' => '28',
        'ac_id' => '4',
        'article_url' => '',
        'article_title' => '分期付款',
        'article_time' => '1389864697',
        'ac_name' => '支付方式',
        'ac_parent_id' => '0',
      ),
      2 => 
      array (
        'article_id' => '30',
        'ac_id' => '4',
        'article_url' => '',
        'article_title' => '公司转账',
        'article_time' => '1389864697',
        'ac_name' => '支付方式',
        'ac_parent_id' => '0',
      ),
      3 => 
      array (
        'article_id' => '17',
        'ac_id' => '4',
        'article_url' => '',
        'article_title' => '在线支付',
        'article_time' => '1389864697',
        'ac_name' => '支付方式',
        'ac_parent_id' => '0',
      ),
      4 => 
      array (
        'article_id' => '29',
        'ac_id' => '4',
        'article_url' => '',
        'article_title' => '邮局汇款',
        'article_time' => '1389864697',
        'ac_name' => '支付方式',
        'ac_parent_id' => '0',
      ),
    ),
    'class' => 
    array (
      'ac_name' => '支付方式',
    ),
  ),
  3 => 
  array (
    'ac_id' => '5',
    'ac_code' => 'sold',
    'ac_name' => '售后服务',
    'ac_parent_id' => '0',
    'ac_sort' => '255',
    'list' => 
    array (
      0 => 
      array (
        'article_id' => '33',
        'ac_id' => '5',
        'article_url' => '',
        'article_title' => '返修/退换货',
        'article_time' => '1389864697',
        'ac_name' => '售后服务',
        'ac_parent_id' => '0',
      ),
      1 => 
      array (
        'article_id' => '26',
        'ac_id' => '5',
        'article_url' => '',
        'article_title' => '联系卖家',
        'article_time' => '1389864697',
        'ac_name' => '售后服务',
        'ac_parent_id' => '0',
      ),
      2 => 
      array (
        'article_id' => '32',
        'ac_id' => '5',
        'article_url' => '',
        'article_title' => '退换货流程',
        'article_time' => '1389864697',
        'ac_name' => '售后服务',
        'ac_parent_id' => '0',
      ),
      3 => 
      array (
        'article_id' => '34',
        'ac_id' => '5',
        'article_url' => '',
        'article_title' => '退款申请',
        'article_time' => '1389864697',
        'ac_name' => '售后服务',
        'ac_parent_id' => '0',
      ),
      4 => 
      array (
        'article_id' => '31',
        'ac_id' => '5',
        'article_url' => '',
        'article_title' => '退换货政策',
        'article_time' => '1389864697',
        'ac_name' => '售后服务',
        'ac_parent_id' => '0',
      ),
    ),
    'class' => 
    array (
      'ac_name' => '售后服务',
    ),
  ),
  4 => 
  array (
    'ac_id' => '6',
    'ac_code' => 'service',
    'ac_name' => '客服中心',
    'ac_parent_id' => '0',
    'ac_sort' => '255',
    'list' => 
    array (
      0 => 
      array (
        'article_id' => '21',
        'ac_id' => '6',
        'article_url' => '',
        'article_title' => '修改收货地址',
        'article_time' => '1389864697',
        'ac_name' => '客服中心',
        'ac_parent_id' => '0',
      ),
      1 => 
      array (
        'article_id' => '18',
        'ac_id' => '6',
        'article_url' => '',
        'article_title' => '会员修改密码',
        'article_time' => '1389864697',
        'ac_name' => '客服中心',
        'ac_parent_id' => '0',
      ),
      2 => 
      array (
        'article_id' => '20',
        'ac_id' => '6',
        'article_url' => '',
        'article_title' => '商品发布',
        'article_time' => '1389864697',
        'ac_name' => '客服中心',
        'ac_parent_id' => '0',
      ),
      3 => 
      array (
        'article_id' => '19',
        'ac_id' => '6',
        'article_url' => '',
        'article_title' => '会员修改个人资料',
        'article_time' => '1389864697',
        'ac_name' => '客服中心',
        'ac_parent_id' => '0',
      ),
    ),
    'class' => 
    array (
      'ac_name' => '客服中心',
    ),
  ),
  5 => 
  array (
    'ac_id' => '7',
    'ac_code' => 'about',
    'ac_name' => '关于我们',
    'ac_parent_id' => '0',
    'ac_sort' => '255',
    'list' => 
    array (
      0 => 
      array (
        'article_id' => '24',
        'ac_id' => '7',
        'article_url' => '',
        'article_title' => '招聘英才',
        'article_time' => '1389864697',
        'ac_name' => '关于我们',
        'ac_parent_id' => '0',
      ),
      1 => 
      array (
        'article_id' => '23',
        'ac_id' => '7',
        'article_url' => '',
        'article_title' => '联系我们',
        'article_time' => '1389864697',
        'ac_name' => '关于我们',
        'ac_parent_id' => '0',
      ),
      2 => 
      array (
        'article_id' => '25',
        'ac_id' => '7',
        'article_url' => '',
        'article_title' => '合作及洽谈',
        'article_time' => '1389864697',
        'ac_name' => '关于我们',
        'ac_parent_id' => '0',
      ),
      3 => 
      array (
        'article_id' => '22',
        'ac_id' => '7',
        'article_url' => '',
        'article_title' => '关于我们',
        'article_time' => '1389864697',
        'ac_name' => '关于我们',
        'ac_parent_id' => '0',
      ),
    ),
    'class' => 
    array (
      'ac_name' => '关于我们',
    ),
  ),
);
?>