<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  'ap_id' => '11',
  'ap_name' => '首页中上部banner',
  'ap_intro' => '物流自取广告',
  'ap_class' => '0',
  'ap_display' => '2',
  'is_use' => '1',
  'ap_width' => '1200',
  'ap_height' => '100',
  'ap_price' => '100',
  'adv_num' => '2',
  'click_num' => '0',
  'default_content' => 'banner.gif',
  'adv_list' => 
  array (
    0 => 
    array (
      'adv_id' => '935',
      'ap_id' => '11',
      'adv_title' => '物流自提服务站',
      'adv_content' => 'a:2:{s:7:"adv_pic";s:21:"04878484309098960.gif";s:11:"adv_pic_url";s:10:"/delivery/";}',
      'adv_start_date' => '1433260800',
      'adv_end_date' => '1527782400',
      'slide_sort' => '0',
      'member_id' => '0',
      'member_name' => '',
      'click_num' => '0',
      'is_allow' => '1',
      'buy_style' => '',
      'goldpay' => '0',
    ),
  ),
);