<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  'ap_id' => '1047',
  'ap_name' => '首页顶部广告',
  'ap_intro' => '',
  'ap_class' => '0',
  'ap_display' => '2',
  'is_use' => '1',
  'ap_width' => '1200',
  'ap_height' => '80',
  'ap_price' => '0',
  'adv_num' => '1',
  'click_num' => '0',
  'default_content' => '04964056092987731.jpg',
  'adv_list' => 
  array (
    0 => 
    array (
      'adv_id' => '936',
      'ap_id' => '1047',
      'adv_title' => '顶部广告',
      'adv_content' => 'a:2:{s:7:"adv_pic";s:21:"04964060432258357.jpg";s:11:"adv_pic_url";s:19:"http://mall.wrtx.cn";}',
      'adv_start_date' => '1433347200',
      'adv_end_date' => '1624982400',
      'slide_sort' => '0',
      'member_id' => '0',
      'member_name' => '',
      'click_num' => '0',
      'is_allow' => '1',
      'buy_style' => '',
      'goldpay' => '0',
    ),
  ),
);