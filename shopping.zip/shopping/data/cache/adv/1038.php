<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  'ap_id' => '1038',
  'ap_name' => '闲置首页中部横栏广告',
  'ap_intro' => '闲置首页中部横栏广告',
  'ap_class' => '0',
  'ap_display' => '1',
  'is_use' => '1',
  'ap_width' => '1200',
  'ap_height' => '80',
  'ap_price' => '30',
  'adv_num' => '2',
  'click_num' => '0',
  'default_content' => 'c861866014826de9d2a85cb9b592007c.jpg',
  'adv_list' => 
  array (
    0 => 
    array (
      'adv_id' => '920',
      'ap_id' => '1038',
      'adv_title' => '闲置横栏广告1',
      'adv_content' => 'a:2:{s:7:"adv_pic";s:21:"04964067375451751.jpg";s:11:"adv_pic_url";s:19:"http://mall.wrtx.cn";}',
      'adv_start_date' => '1325347200',
      'adv_end_date' => '1622476800',
      'slide_sort' => '0',
      'member_id' => '0',
      'member_name' => '',
      'click_num' => '1',
      'is_allow' => '1',
      'buy_style' => '',
      'goldpay' => '0',
    ),
  ),
);