<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  'ap_id' => '1048',
  'ap_name' => '首页底部通栏图片广告',
  'ap_intro' => '',
  'ap_class' => '0',
  'ap_display' => '2',
  'is_use' => '1',
  'ap_width' => '1200',
  'ap_height' => '100',
  'ap_price' => '0',
  'adv_num' => '0',
  'click_num' => '0',
  'default_content' => '04955683052399958.jpg',
);