<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  'ap_id' => '1044',
  'ap_name' => '闲置首页中部短栏广告2',
  'ap_intro' => '闲置首页中部短栏广告2',
  'ap_class' => '0',
  'ap_display' => '2',
  'is_use' => '1',
  'ap_width' => '240',
  'ap_height' => '100',
  'ap_price' => '30',
  'adv_num' => '1',
  'click_num' => '0',
  'default_content' => '04961715044283090.jpg',
  'adv_list' => 
  array (
    0 => 
    array (
      'adv_id' => '932',
      'ap_id' => '1044',
      'adv_title' => '闲置首页中部短栏广告2',
      'adv_content' => 'a:2:{s:7:"adv_pic";s:21:"04964064439712945.jpg";s:11:"adv_pic_url";s:19:"http://mall.wrtx.cn";}',
      'adv_start_date' => '1328025600',
      'adv_end_date' => '1622476800',
      'slide_sort' => '0',
      'member_id' => '0',
      'member_name' => '',
      'click_num' => '0',
      'is_allow' => '1',
      'buy_style' => '',
      'goldpay' => '0',
    ),
  ),
);