<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  'ap_id' => '35',
  'ap_name' => '积分列表页中部广告位',
  'ap_intro' => '积分列表页中部广告位',
  'ap_class' => '0',
  'ap_display' => '2',
  'is_use' => '1',
  'ap_width' => '900',
  'ap_height' => '368',
  'ap_price' => '30',
  'adv_num' => '0',
  'click_num' => '0',
  'default_content' => 'f448e48ee0deb06707480d46a2a360ae.gif',
);