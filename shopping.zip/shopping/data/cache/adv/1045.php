<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  'ap_id' => '1045',
  'ap_name' => '闲置首页中部短栏广告3',
  'ap_intro' => '闲置首页中部短栏广告3',
  'ap_class' => '0',
  'ap_display' => '2',
  'is_use' => '1',
  'ap_width' => '240',
  'ap_height' => '100',
  'ap_price' => '30',
  'adv_num' => '1',
  'click_num' => '0',
  'default_content' => '04961715237318667.jpg',
  'adv_list' => 
  array (
    0 => 
    array (
      'adv_id' => '933',
      'ap_id' => '1045',
      'adv_title' => '闲置首页中部短栏广告3',
      'adv_content' => 'a:2:{s:7:"adv_pic";s:21:"04964064800664735.jpg";s:11:"adv_pic_url";s:19:"http://mall.wrtx.cn";}',
      'adv_start_date' => '1328025600',
      'adv_end_date' => '1622476800',
      'slide_sort' => '0',
      'member_id' => '0',
      'member_name' => '',
      'click_num' => '0',
      'is_allow' => '1',
      'buy_style' => '',
      'goldpay' => '0',
    ),
  ),
);