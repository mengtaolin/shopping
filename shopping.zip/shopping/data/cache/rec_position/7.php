<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  'rec_id' => '7',
  'pic_type' => '0',
  'title' => '新浪微博',
  'content' => 'a:2:{s:4:"body";a:1:{i:0;a:2:{s:5:"title";s:12:"新浪微博";s:3:"url";s:0:"";}}s:6:"target";i:2;}',
);