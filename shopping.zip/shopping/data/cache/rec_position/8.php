<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  'rec_id' => '8',
  'pic_type' => '0',
  'title' => '腾讯微博',
  'content' => 'a:2:{s:4:"body";a:1:{i:0;a:2:{s:5:"title";s:12:"腾讯微博";s:3:"url";s:0:"";}}s:6:"target";i:2;}',
);