<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  'rec_id' => '5',
  'pic_type' => '1',
  'title' => '底部推荐5',
  'content' => 'a:4:{s:4:"body";a:1:{i:0;a:2:{s:5:"title";s:42:"shop/rec_position/3497c1b195bde1928550.png";s:3:"url";s:0:"";}}s:5:"width";s:0:"";s:6:"height";s:0:"";s:6:"target";i:1;}',
);