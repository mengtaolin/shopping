<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
);