<?php defined('InWrzcNet') or exit('Access Invalid!'); return array (
  1 => 
  array (
    'sg_id' => '1',
    'sg_name' => '系统默认',
    'sg_goods_limit' => '0',
    'sg_album_limit' => '0',
    'sg_space_limit' => '100',
    'sg_template_number' => '6',
    'sg_template' => 'default|style1|style2|style3|style4|style5',
    'sg_price' => '100.00',
    'sg_description' => '用户选择“默认等级”，可以立即开通。',
    'sg_function' => 'editor_multimedia',
    'sg_sort' => '0',
  ),
  2 => 
  array (
    'sg_id' => '2',
    'sg_name' => '白金店铺',
    'sg_goods_limit' => '0',
    'sg_album_limit' => '0',
    'sg_space_limit' => '100',
    'sg_template_number' => '6',
    'sg_template' => 'default|style1|style2|style3|style4|style5',
    'sg_price' => '200.00',
    'sg_description' => '享受更多特权',
    'sg_function' => 'editor_multimedia',
    'sg_sort' => '2',
  ),
  3 => 
  array (
    'sg_id' => '3',
    'sg_name' => '钻石店铺',
    'sg_goods_limit' => '0',
    'sg_album_limit' => '0',
    'sg_space_limit' => '100',
    'sg_template_number' => '6',
    'sg_template' => 'default|style1|style2|style3|style4|style5',
    'sg_price' => '1000.00',
    'sg_description' => '',
    'sg_function' => 'editor_multimedia',
    'sg_sort' => '100',
  ),
);